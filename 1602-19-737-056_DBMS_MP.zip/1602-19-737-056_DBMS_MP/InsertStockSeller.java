package dbms_project;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class InsertStockSeller extends Frame{
    Button insertSSButton;
    TextField BillIDText, companynameText, ProductIDText, ProductQuantText ,CostText, OverallCostText , OrderedDText, ReceivedDText, DateText, CompanyAddText;
    TextArea errorText;
    Connection connection;
    Statement statement;
    public static void main(String[] args){
        InsertStockSeller s = new InsertStockSeller();
    }
    public InsertStockSeller(){
         try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it19737056","vasavi");
            statement = connection.createStatement();
            buildGUI();
            System.out.println("Connected!!");
        } 
        catch (SQLException connectException) {
            System.out.println(connectException.getMessage());
            System.out.println(connectException.getSQLState());
            System.out.println(connectException.getErrorCode());
            System.exit(1);
        }
    }
    public void buildGUI() {
    //Handle Insert Account Button
        insertSSButton = new Button("INSERT");
        insertSSButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                try{
                    //String query = "INSERT INTO sailors (SID,SNAME, RATING, AGE) VALUES (2,'Divya',7,20)"; 
                    String query= "INSERT INTO Stock_Seller VALUES(" + "'" + BillIDText.getText() + "','" + 
                                                                              companynameText.getText() + "','" + 
                                                                              ProductIDText.getText() + "','" + 
                                                                              ProductQuantText.getText() + "'," + 
                                                                              CostText.getText() + "," + 
                                                                              OverallCostText.getText() + ",'" + 
                                                                              OrderedDText.getText() + "','" + 
                                                                              ReceivedDText.getText() + "','" +
                                                                              DateText.getText() + "','" + 
                                                                              CompanyAddText.getText() + 
                                                                              "')";
                    int i = statement.executeUpdate(query);
                    errorText.append("\nInserted " + i + " rows successfully");
                } 
                catch (SQLException insertException) {
                    displaySQLErrors(insertException);
                }
            }
        });
        BillIDText = new TextField(20);
        companynameText = new TextField(20);
        ProductIDText = new TextField(20);
        ProductQuantText = new TextField(20);
        CostText = new TextField(20);
        OverallCostText = new TextField(30);
        OrderedDText = new TextField(20);
        ReceivedDText = new TextField(20);
        DateText = new TextField(20);
        CompanyAddText = new TextField(20);
        errorText = new TextArea(10, 40);
        errorText.setEditable(false);
        Panel first = new Panel();
        first.setLayout(new GridLayout(10,2));
        first.add(new Label("Bill ID:"));
        first.add(BillIDText);
        first.add(new Label("Company Name:"));
        first.add(companynameText);
        first.add(new Label("Product ID:"));
        first.add(ProductIDText);
        first.add(new Label("Product Qunatity:"));
        first.add(ProductQuantText);
        first.add(new Label("Unit Cost:"));
        first.add(CostText);
        first.add(new Label("Overall Cost:"));
        first.add(OverallCostText);
        first.add(new Label("Ordered Date:"));
        first.add(OrderedDText);
        first.add(new Label("Received Date:"));
        first.add(ReceivedDText);
        first.add(new Label("Bill Date:"));
        first.add(DateText);
        first.add(new Label("Company address:"));
        first.add(CompanyAddText);
        first.setBounds(50,50,400,400);
        Panel second = new Panel(new GridLayout(4, 1));
        second.add(insertSSButton);
        second.setBounds(500,200,150,220); 
        Panel third = new Panel();
        third.add(errorText);
        third.setBounds(250,550,300,250);
        setLayout(null);
        add(first);
        add(second);
        add(third); 
        setTitle("Insert Gets");
        first.setBackground(Color.CYAN);
        setSize(800, 800);
        setVisible(true);
    }
    public void displaySQLErrors(SQLException e) {
        errorText.append("\nSQLException: " + e.getMessage() + "\n");
        errorText.append("SQLState: " + e.getSQLState() + "\n");
        errorText.append("VendorError: " + e.getErrorCode() + "\n");
    }
}