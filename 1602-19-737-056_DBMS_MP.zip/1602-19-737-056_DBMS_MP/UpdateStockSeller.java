package dbms_project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UpdateStockSeller extends Frame{
    JFrame frame = new JFrame("Updating Stock Seller");

    JLabel heading = new JLabel("UPDATE Stock Seller");

    JLabel BillID = new JLabel("Enter Bill ID : ");
    JLabel CompName = new JLabel("Enter Company Name: ");
    JLabel ProductID = new JLabel("Enter Product ID : ");
    JLabel ProductQuant = new JLabel("Enter Quantity : ");
    JLabel Cost = new JLabel("Enter Cost: ");
    JLabel OCost = new JLabel("Enter Overall Cost: ");
    JLabel OrderedD = new JLabel("Enter Oredered Date: ");
    JLabel ReceivedD = new JLabel("Enter Received Date: ");
    JLabel BDate = new JLabel("Enter Bill date: ");
    JLabel CompAdd = new JLabel("Enter Company Address: ");
    
    List ids = new List(15);
    
    JTextField BillIDText = new JTextField();
    JTextField CompNameText = new JTextField();
    JTextField ProductIDText = new JTextField();
    JTextField ProductQuantText = new JTextField();
    JTextField CostText = new JTextField();
    JTextField OCostText = new JTextField();
    JTextField OrderedDText = new JTextField();
    JTextField ReceivedDText = new JTextField();
    JTextField BDateText = new JTextField();
    JTextField CompAddText = new JTextField();
    
    JTextArea resultText = new JTextArea();
    
    JButton update = new JButton("MODIFY");

    Statement stmt;
    public static void main(String[] args){
        UpdateStockSeller s = new UpdateStockSeller();
    }
    
    public void connDb() {
    	try{
            //Class.forName("oracle.jdbc.driver.OracleDriver");
        
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it19737056","vasavi");
            stmt = con.createStatement();
            System.out.println("connection successful");
//            con.close();
        }
        catch(SQLException e){
            System.out.println(e);
        }
    }

    public void loadProducts(){

        try 
        {
          ResultSet rs;
          rs = stmt.executeQuery("SELECT bill_id FROM Stock_Seller");
          while (rs.next()) 
          {
            ids.add(rs.getString(1));
          }
        } 
        catch (SQLException e) 
        { 
          displaySQLErrors(e);
        }
    }
    private void displaySQLErrors(SQLException e) 
    {
        JOptionPane.showMessageDialog(frame,"Enter valid data types");  
        resultText.append("\nSQLException: " + e.getMessage() + "\n");
        resultText.append("SQLState:     " + e.getSQLState() + "\n");
        resultText.append("VendorError:  " + e.getErrorCode() + "\n");
    }

    public UpdateStockSeller(){
    	
    	connDb();
        loadProducts();
        
        frame.getContentPane().setBackground(Color.PINK);
        
        ids.setBounds(50, 100, 200, 350);
        heading.setBounds(150, 50, 100, 20);
        BillID.setBounds(300, 50, 100, 30);
        CompName.setBounds(300, 100, 200, 30);
        BillIDText.setBounds(450, 50, 150, 30);
       	CompNameText.setBounds(450, 100, 150, 30);
        ProductID.setBounds(300, 150, 150, 30);
        ProductIDText.setBounds(450, 150, 150, 30);
        ProductQuant.setBounds(300, 200, 150, 30);
        ProductQuantText.setBounds(450, 200,150, 30);
        Cost.setBounds(300, 250, 150, 30);
        CostText.setBounds(450, 250, 150, 30);
        OCost.setBounds(300, 300, 150, 30);
        OCostText.setBounds(450, 300, 150, 30);
        OrderedD.setBounds(300,350,150,30);
        OrderedDText.setBounds(450,350,150,30);
        ReceivedD.setBounds(300,400,150,30);
        ReceivedDText.setBounds(450,400,150,30);
        BDate.setBounds(300,450,150,30);
        BDateText.setBounds(450,450,150,30);
        CompAdd.setBounds(300,500,150,30);
        CompAddText.setBounds(450,500,150,30);
        resultText.setBounds(200, 550, 400, 200);
       
        update.setBounds(50, 470, 100, 30);
        
        frame.add(ids);
        frame.add(heading);
        frame.add(BillID);
        frame.add(CompName);
        frame.add(BillIDText);
        frame.add(CompNameText);
        frame.add(ProductID);
        frame.add(ProductQuant);
        frame.add(Cost);
        frame.add(OCost);
        frame.add(OrderedD);
        frame.add(ReceivedD);
        frame.add(BDate);
        frame.add(CompAdd);
        frame.add(ProductIDText);
        frame.add(ProductQuantText);
        frame.add(CostText);
        frame.add(OCostText);
        frame.add(OrderedDText);
        frame.add(ReceivedDText);
        frame.add(BDateText);
        frame.add(CompAddText);
        frame.add(update);
        frame.add(resultText);
        
        frame.setLayout(null);  
        frame.setVisible(true);
        frame.setBounds(10, 10, 700, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);  

        ids.addItemListener(new ItemListener() {
		public void itemStateChanged(ItemEvent ae) {
            
            try     
            {
            	    ResultSet rs;
                    rs = stmt.executeQuery("SELECT * FROM Stock_Seller where bill_id ='"+ids.getSelectedItem()+"'");
                    rs.next();
                    BillIDText.setText(rs.getString(1));
                    CompNameText.setText(rs.getString(2));
                    ProductIDText.setText(rs.getString(3));
                    ProductQuantText.setText(rs.getString(4));
                    CostText.setText(rs.getString(5));
                    OCostText.setText(rs.getString(6));
                    OrderedDText.setText(rs.getString(7));
                    ReceivedDText.setText(rs.getString(8));
                    BDateText.setText(rs.getString(9));
                    CompAddText.setText(rs.getString(10));
                } 
                catch (SQLException selectException) 
                {
                    displaySQLErrors(selectException);
                }
        }});
        
        update.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            try 
                {   
                    int i = stmt.executeUpdate("UPDATE Stock_Seller "
                    + "SET bill_id='" + BillIDText.getText() + "', "
                    + "compname='" + CompNameText.getText() + "', "
                    + "product_id='" + ProductIDText.getText() + "',"
                    + "product_quantity='" + ProductQuantText.getText() + "', "
                    + "product_cost=" + CostText.getText() + ", "
                    + "overallcost=" + OCostText.getText() + "," 
                    + "OrderedD='" + OrderedDText.getText() + "',"
                    + "ReceivedD='" + ReceivedDText.getText() + "'," 
                    + "bdate='" + BDateText.getText() +"',"
                    + "compadd='" + CompAddText.getText() + "'"
                    +" WHERE bill_id = '"
                    + ids.getSelectedItem()+"'");
                    
                    resultText.append("\nUpdated " + i + " rows successfully");
                    ids.removeAll();
                    loadProducts();
                } 
                catch(SQLException insertException) {
                    displaySQLErrors(insertException);
                }
        }});
    }
}
