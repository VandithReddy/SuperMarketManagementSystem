package dbms_project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DeleteStorageUnits {
    JFrame frame = new JFrame("Deleting Storage Unit");

    JLabel heading = new JLabel("DELETE Storage Unit");

    JLabel SUID = new JLabel("Enter SU id : ");
    JLabel SUPlace = new JLabel("Enter SU place : ");
    JLabel ProductID = new JLabel("Enter Product ID : ");
    JLabel ProductQuant = new JLabel("Enter Quantity : ");
    JLabel ProductExpiryDate = new JLabel("Enter Expiry date : ");
    JLabel SUtype = new JLabel("Enter SU type : ");
    JLabel SUmngr = new JLabel("Enter Manager name : ");
    JLabel SUmngrID = new JLabel("Enter manager ID : ");
    JLabel SUmngrph = new JLabel("Enter manager phno : ");
    JLabel ProdRem = new JLabel("Enter Product Rem : ");
    
    List ids = new List(15);
    
    JTextField SUIDText = new JTextField();
    JTextField SUplaceText = new JTextField();
    JTextField ProductIDText = new JTextField();
    JTextField ProductQuantText = new JTextField();
    JTextField ProductEDText = new JTextField();
    JTextField SUTypeText = new JTextField();
    JTextField SUmngrText = new JTextField();
    JTextField SUmngrIDText = new JTextField();
    JTextField SUmngrphText = new JTextField();
    JTextField ProdRemText = new JTextField();
    
    JTextArea resultText = new JTextArea();
    
    JButton delete = new JButton("DELETE");

    Statement stmt;
    public static void main(String[] args){
        DeleteStorageUnits s = new DeleteStorageUnits();
    }
    
    public void connDb() {
    	try{
            //Class.forName("oracle.jdbc.driver.OracleDriver");
        
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it19737056","vasavi");
            stmt = con.createStatement();
            System.out.println("connection successful");
//            con.close();
        }
        catch(SQLException e){
            System.out.println(e);
        }
    }

    public void loadProducts(){

        try 
        {
          ResultSet rs;
          rs = stmt.executeQuery("SELECT suid FROM storage_units");
          while (rs.next()) 
          {
            ids.add(rs.getString(1));
          }
        } 
        catch (SQLException e) 
        { 
          displaySQLErrors(e);
        }
    }
    private void displaySQLErrors(SQLException e) 
    {
        JOptionPane.showMessageDialog(frame,"Enter valid data types");  
        resultText.append("\nSQLException: " + e.getMessage() + "\n");
        resultText.append("SQLState:     " + e.getSQLState() + "\n");
        resultText.append("VendorError:  " + e.getErrorCode() + "\n");
    }
    public DeleteStorageUnits(){
    	
    	connDb();
        loadProducts();
        
        frame.getContentPane().setBackground(Color.LIGHT_GRAY);
        
        ids.setBounds(50, 100, 200, 350);
        heading.setBounds(150, 50, 100, 20);
        SUID.setBounds(300, 50, 100, 30);
        SUPlace.setBounds(300, 100, 200, 30);
        SUIDText.setBounds(450, 50, 150, 30);
       	SUplaceText.setBounds(450, 100, 150, 30);
        ProductID.setBounds(300, 150, 150, 30);
        ProductIDText.setBounds(450, 150, 150, 30);
        ProductQuant.setBounds(300, 200, 150, 30);
        ProductQuantText.setBounds(450, 200,150, 30);
        ProductExpiryDate.setBounds(300, 250, 150, 30);
        ProductEDText.setBounds(450, 250, 150, 30);
        SUtype.setBounds(300, 300, 150, 30);
        SUTypeText.setBounds(450, 300, 150, 30);
        SUmngr.setBounds(300,350,150,30);
        SUmngrText.setBounds(450,350,150,30);
        SUmngrID.setBounds(300,400,150,30);
        SUmngrIDText.setBounds(450,400,150,30);
        SUmngrph.setBounds(300,450,150,30);
        SUmngrphText.setBounds(450,450,150,30);
        ProdRem.setBounds(300,500,150,30);
        ProdRemText.setBounds(450,500,150,30);
        resultText.setBounds(200, 550, 400, 200);
       
        delete.setBounds(50, 470, 100, 30);
        
        frame.add(ids);
        frame.add(heading);
        frame.add(SUID);
        frame.add(SUPlace);
        frame.add(SUIDText);
        frame.add(SUplaceText);
        frame.add(ProductID);
        frame.add(ProductQuant);
        frame.add(ProductExpiryDate);
        frame.add(SUtype);
        frame.add(SUmngr);
        frame.add(SUmngrID);
        frame.add(SUmngrph);
        frame.add(ProdRem);
        frame.add(ProductIDText);
        frame.add(ProductQuantText);
        frame.add(ProductEDText);
        frame.add(SUTypeText);
        frame.add(SUmngrText);
        frame.add(SUmngrIDText);
        frame.add(SUmngrphText);
        frame.add(ProdRemText);
        frame.add(delete);
        frame.add(resultText);
        
        frame.setLayout(null);  
        frame.setVisible(true);
        frame.setBounds(10, 10, 700, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        
        ids.addItemListener(new ItemListener() {
		public void itemStateChanged(ItemEvent ae) {
            
            try     
            {
            	    ResultSet rs;
                    rs = stmt.executeQuery("SELECT * FROM storage_units where suid ='"+ids.getSelectedItem()+"'");
                    rs.next();
                    SUIDText.setText(rs.getString(1));
                    SUplaceText.setText(rs.getString(2));
                    ProductIDText.setText(rs.getString(3));
                    ProductQuantText.setText(rs.getString(4));
                    ProductEDText.setText(rs.getString(5));
                    SUTypeText.setText(rs.getString(6));
                    SUmngrText.setText(rs.getString(7));
                    SUmngrIDText.setText(rs.getString(8));
                    SUmngrphText.setText(rs.getString(9));
                    ProdRemText.setText(rs.getString(10));
                } 
                catch (SQLException selectException) 
                {
                    displaySQLErrors(selectException);
                }
        }});
        delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
					int i = stmt.executeUpdate("DELETE FROM storage_units WHERE suid = '" + ids.getSelectedItem()+"'");
					resultText.append("\nDeleted " + i + " rows successfully");
					ids.removeAll();
					loadProducts();
				} catch (SQLException insertException) {
					displaySQLErrors(insertException);
				}

			}
		});
	}
}
