package dbms_project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DeleteProduct extends Frame{
	JFrame frame = new JFrame("Deleting products");

	JLabel heading = new JLabel("DELETE PRODUCT");

	JLabel ProductID = new JLabel("Enter product id : ");
	JLabel Productname = new JLabel("Enter product name : ");
	JLabel ProductED = new JLabel("Enter product expiry date: ");
	JLabel ProductQuant = new JLabel("Enter qunatity : ");
	JLabel ProductCost = new JLabel("Enter the cost : ");
	JLabel ProductType = new JLabel("Enter the type : ");

	List ids = new List(15);

	JTextField ProductIDText = new JTextField();
	JTextField ProductnameText = new JTextField();
	JTextField ProductEDText = new JTextField();
	JTextField ProductQuantText = new JTextField();
	JTextField ProductCostText = new JTextField();
	JTextField ProductTypeText = new JTextField();

	JTextArea resultText = new JTextArea();
        
	JButton delete = new JButton("DELETE");

	Statement stmt;
        public static void main(String[] args){
            DeleteProduct s = new DeleteProduct();
        }

	public void connDb() {
		try {

			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms", "it19737056",
					"vasavi");
			stmt = con.createStatement();
			System.out.println("connection successful");
		} catch (SQLException e) {
			System.out.println(e);
		}
	}

	public void loadProducts() {

		try {
			ResultSet rs;
			rs = stmt.executeQuery("SELECT product_id FROM Product");
			while (rs.next()) {
				ids.add(rs.getString(1));
			}
		} catch (SQLException e) {
			displaySQLErrors(e);
		}
	}

	private void displaySQLErrors(SQLException e) {
		JOptionPane.showMessageDialog(frame, "Enter valid data types");
		resultText.append("\nSQLException: " + e.getMessage() + "\n");
		resultText.append("SQLState:     " + e.getSQLState() + "\n");
		resultText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public DeleteProduct() {

		connDb();
		loadProducts();

		ids.setBounds(50, 100, 200, 350);
		heading.setBounds(150, 50, 200, 20);
		ProductID.setBounds(300, 100, 200, 30);
		Productname.setBounds(300, 150, 200, 30);
		ProductIDText.setBounds(450, 100, 150, 30);
		ProductnameText.setBounds(450, 150, 150, 30);
		ProductED.setBounds(300, 200, 150, 30);
		ProductEDText.setBounds(450, 200, 150, 30);
		ProductQuant.setBounds(300, 250, 150, 30);
		ProductQuantText.setBounds(450, 250, 150, 30);
		ProductCost.setBounds(300, 300, 150, 30);
		ProductCostText.setBounds(450, 300, 150, 30);
		ProductType.setBounds(300, 350, 150, 30);
		ProductTypeText.setBounds(450, 350, 150, 30);
		resultText.setBounds(300, 450, 300, 150);

		delete.setBounds(50, 470, 100, 30);

		frame.getContentPane().setBackground(Color.gray);

		frame.add(ids);
		frame.add(heading);
		frame.add(ProductID);
		frame.add(Productname);
		frame.add(ProductIDText);
		frame.add(ProductnameText);
		frame.add(ProductED);
		frame.add(ProductQuant);
		frame.add(ProductCost);
		frame.add(ProductType);
		frame.add(ProductEDText);
		frame.add(ProductQuantText);
		frame.add(ProductCostText);
		frame.add(ProductTypeText);
		frame.add(delete);
		frame.add(resultText);

		frame.setLayout(null);
		frame.setVisible(true);
		frame.setBounds(10, 10, 700, 700);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);

		ids.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ae) {

				try {
					ResultSet rs;
					rs = stmt.executeQuery("SELECT * FROM Product where product_id ='" + ids.getSelectedItem() + "'");
					rs.next();
					ProductIDText.setText(rs.getString(1));
					ProductnameText.setText(rs.getString(2));
					ProductEDText.setText(rs.getString(3));
					ProductQuantText.setText(rs.getString(4));
					ProductTypeText.setText(rs.getString(6));
					ProductCostText.setText(rs.getString(5));
					//tDescription.setText(rs.getString(7));

				} catch (SQLException selectException) {
					displaySQLErrors(selectException);
				}
			}
		});

		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
					int i = stmt.executeUpdate("DELETE FROM Product WHERE product_id = " + ids.getSelectedItem());
					resultText.append("\nDeleted " + i + " rows successfully");
					ids.removeAll();
					loadProducts();
				} catch (SQLException insertException) {
					displaySQLErrors(insertException);
				}

			}
		});
	}
}
