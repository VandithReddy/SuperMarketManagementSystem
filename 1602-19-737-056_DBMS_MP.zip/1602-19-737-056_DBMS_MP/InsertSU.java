
package dbms_project;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class InsertSU extends Frame{
    Button insertProductButton;
    TextField SUIDText, SUplaceText, ProductIDText, ProductQuantText ,ProductEDText, SUTypeText , SUmngrText, SUmngrIDText, SUmngrphText, ProductRemText;
    TextArea errorText;
    Connection connection;
    Statement statement;
    public static void main(String[] args){
        InsertSU s = new InsertSU();
    }
    public InsertSU(){
         try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it19737056","vasavi");
            statement = connection.createStatement();
            buildGUI();
            System.out.println("Connected!!");
        } 
        catch (SQLException connectException) {
            System.out.println(connectException.getMessage());
            System.out.println(connectException.getSQLState());
            System.out.println(connectException.getErrorCode());
            System.exit(1);
        }
    }
    public void buildGUI() {
    //Handle Insert Account Button
        insertProductButton = new Button("Insert Storage Unit");
        insertProductButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                try{
                    //String query = "INSERT INTO sailors (SID,SNAME, RATING, AGE) VALUES (2,'Divya',7,20)"; 
                    String query= "INSERT INTO storage_units VALUES(" + "'" + SUIDText.getText() + "','" + 
                                                                              SUplaceText.getText() + "','" + 
                                                                              ProductIDText.getText() + "','" + 
                                                                              ProductQuantText.getText() + "','" + 
                                                                              ProductEDText.getText() + "','" + 
                                                                              SUTypeText.getText() + "','" + 
                                                                              SUmngrText.getText() + "','" + 
                                                                              SUmngrIDText.getText() + "','" +
                                                                              SUmngrphText.getText() + "','" + 
                                                                              ProductRemText.getText() + 
                                                                              "')";
                    int i = statement.executeUpdate(query);
                    errorText.append("\nInserted " + i + " rows successfully");
                } 
                catch (SQLException insertException) {
                    displaySQLErrors(insertException);
                }
            }
        });
        SUIDText = new TextField(20);
        SUplaceText = new TextField(20);
        ProductIDText = new TextField(20);
        ProductQuantText = new TextField(20);
        ProductEDText = new TextField(20);
        SUTypeText = new TextField(30);
        SUmngrText = new TextField(20);
        SUmngrIDText = new TextField(20);
        SUmngrphText = new TextField(20);
        ProductRemText = new TextField(20);
        errorText = new TextArea(10, 40);
        errorText.setEditable(false);
        Panel first = new Panel();
        first.setLayout(new GridLayout(10,2));
        first.add(new Label("StorageUnit ID:"));
        first.add(SUIDText);
        first.add(new Label("StorageUnit Place:"));
        first.add(SUplaceText);
        first.add(new Label("Product ID:"));
        first.add(ProductIDText);
        first.add(new Label("Product Qunatity:"));
        first.add(ProductQuantText);
        first.add(new Label("Product ExpiryDate:"));
        first.add(ProductEDText);
        first.add(new Label("StorageUnit Type:"));
        first.add(SUTypeText);
        first.add(new Label("Manager name:"));
        first.add(SUmngrText);
        first.add(new Label("Manager ID:"));
        first.add(SUmngrIDText);
        first.add(new Label("Manager PHno:"));
        first.add(SUmngrphText);
        first.add(new Label("Product Remaining:"));
        first.add(ProductRemText);
        first.setBounds(50,50,400,400);
        Panel second = new Panel(new GridLayout(4, 1));
        second.add(insertProductButton);
        second.setBounds(500,200,150,220); 
        Panel third = new Panel();
        third.add(errorText);
        third.setBounds(250,550,300,250);
        setLayout(null);
        add(first);
        add(second);
        add(third); 
        setTitle("Insert Gets");
        first.setBackground(Color.CYAN);
        setSize(800, 800);
        setVisible(true);
    }
    public void displaySQLErrors(SQLException e) {
        errorText.append("\nSQLException: " + e.getMessage() + "\n");
        errorText.append("SQLState: " + e.getSQLState() + "\n");
        errorText.append("VendorError: " + e.getErrorCode() + "\n");
    }
}
    