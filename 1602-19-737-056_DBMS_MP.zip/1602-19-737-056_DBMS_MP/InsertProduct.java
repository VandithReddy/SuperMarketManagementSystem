package dbms_project;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertProduct extends Frame{
    Button insertProductButton;
    TextField ProductIDText, ProductnameText, ProductEDText, ProductQuantText ,ProductcostText, ProductTypeText ;
    TextArea errorText;
    Connection connection;
    Statement statement;
    public static void main(String[] args){
        InsertProduct s = new InsertProduct();
    }
    public InsertProduct(){
        /*try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } 
        catch (Exception e){
            System.err.println("Unable to find and load driver");
            System.exit(1);
        }*/
         try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it19737056","vasavi");
            statement = connection.createStatement();
            buildGUI();
            System.out.println("Connected!!");
        } 
        catch (SQLException connectException) {
            System.out.println(connectException.getMessage());
            System.out.println(connectException.getSQLState());
            System.out.println(connectException.getErrorCode());
            System.exit(1);
        }
    }
    public void buildGUI() {
    //Handle Insert Account Button
        insertProductButton = new Button("Insert Product");
        insertProductButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                try{
                    //String query = "INSERT INTO sailors (SID,SNAME, RATING, AGE) VALUES (2,'Divya',7,20)"; 
                    String query= "INSERT INTO Product VALUES(" + "'" + ProductIDText.getText() + "','" + ProductnameText.getText() + "','" + 
                            ProductEDText.getText() + "','" + ProductQuantText.getText() + "'," + ProductcostText.getText() + ",'" + ProductTypeText.getText() + "'" + ")";
                    int i = statement.executeUpdate(query);
                    errorText.append("\nInserted " + i + " rows successfully");
                } 
                catch (SQLException insertException) {
                    displaySQLErrors(insertException);
                }
            }
        });
        ProductIDText = new TextField(20);
        ProductnameText = new TextField(20);
        ProductQuantText = new TextField(20);
        ProductEDText = new TextField(20);
        ProductcostText = new TextField(20);
        ProductTypeText = new TextField(30);
        errorText = new TextArea(10, 40);
        errorText.setEditable(false);
        Panel first = new Panel();
        first.setLayout(new GridLayout(8,2));
        first.add(new Label("Product ID:"));
        first.add(ProductIDText);
        first.add(new Label("Product Name:"));
        first.add(ProductnameText);
        first.add(new Label("Product Qunatity:"));
        first.add(ProductQuantText);
        first.add(new Label("Product ExpiryDate:"));
        first.add(ProductEDText);
        first.add(new Label("Product Cost:"));
        first.add(ProductcostText);
        first.add(new Label("Product Type:"));
        first.add(ProductTypeText);
        first.setBounds(125,90,250,150);
        Panel second = new Panel(new GridLayout(4, 1));
        second.add(insertProductButton);
        second.setBounds(50,300,150,220); 
        Panel third = new Panel();
        third.add(errorText);
        third.setBounds(250,250,300,250);
        setLayout(null);
        add(first);
        add(second);
        add(third); 
        setTitle("Insert Gets");
        first.setBackground(Color.CYAN);
        setSize(600, 700);
        setVisible(true);
    }
    public void displaySQLErrors(SQLException e) {
        errorText.append("\nSQLException: " + e.getMessage() + "\n");
        errorText.append("SQLState: " + e.getSQLState() + "\n");
        errorText.append("VendorError: " + e.getErrorCode() + "\n");
    }
}
