package dbms_project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UpdateProduct extends Frame{
    JFrame frame = new JFrame("Updating Product");

    JLabel heading = new JLabel("UPDATE PRODUCT");

    JLabel ProductID = new JLabel("Enter product id : ");
    JLabel Productname = new JLabel("Enter product name : ");
    JLabel ProductQuant = new JLabel("Enter Quantity : ");
    JLabel ProductExpiryDate = new JLabel("Enter Expiry date : ");
    JLabel ProductCost = new JLabel("Enter cost : ");
    JLabel Producttype = new JLabel("Enter the type : ");

    List ids = new List(15);
    
    JTextField ProductIDText = new JTextField();
    JTextField ProductnameText = new JTextField();
    JTextField ProductQuantText = new JTextField();
    JTextField ProductEDText = new JTextField();
    JTextField ProductCostText = new JTextField();
    JTextField ProductTypeText = new JTextField();
    
    JTextArea resultText = new JTextArea();
    
    JButton update = new JButton("MODIFY");

    Statement stmt;
    public static void main(String[] args){
        UpdateProduct s = new UpdateProduct();
    }
    
    public void connDb() {
    	try{
            //Class.forName("oracle.jdbc.driver.OracleDriver");
        
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it19737056","vasavi");
            stmt = con.createStatement();
            System.out.println("connection successful");
//            con.close();
        }
        catch(SQLException e){
            System.out.println(e);
        }
    }

    public void loadProducts(){

        try 
        {
          ResultSet rs;
          rs = stmt.executeQuery("SELECT product_id FROM Product");
          while (rs.next()) 
          {
            ids.add(rs.getString(1));
          }
        } 
        catch (SQLException e) 
        { 
          displaySQLErrors(e);
        }
    }
    private void displaySQLErrors(SQLException e) 
    {
        JOptionPane.showMessageDialog(frame,"Enter valid data types");  
        resultText.append("\nSQLException: " + e.getMessage() + "\n");
        resultText.append("SQLState:     " + e.getSQLState() + "\n");
        resultText.append("VendorError:  " + e.getErrorCode() + "\n");
    }

    public UpdateProduct(){
    	
    	connDb();
        loadProducts();
        
        frame.getContentPane().setBackground(Color.PINK);
        
        ids.setBounds(50, 100, 200, 350);
        heading.setBounds(150, 50, 100, 20);
        ProductID.setBounds(300, 100, 100, 30);
        Productname.setBounds(300, 150, 200, 30);
        ProductIDText.setBounds(450, 100, 150, 30);
       	ProductnameText.setBounds(450, 150, 150, 30);
        ProductQuant.setBounds(300, 200, 150, 30);
        ProductQuantText.setBounds(450, 200, 150, 30);
        ProductExpiryDate.setBounds(300, 250, 150, 30);
        ProductEDText.setBounds(450, 250,150, 30);
        ProductCost.setBounds(300, 300, 150, 30);
        ProductCostText.setBounds(450, 300, 150, 30);
        Producttype.setBounds(300, 350, 150, 30);
        ProductTypeText.setBounds(450, 350, 150, 30);
        resultText.setBounds(300, 450, 200, 150);
        
        update.setBounds(50, 470, 100, 30);
        
        frame.add(ids);
        frame.add(heading);
        frame.add(ProductID);
        frame.add(Productname);
        frame.add(ProductIDText);
        frame.add(ProductnameText);
        frame.add(ProductQuant);
        frame.add(ProductExpiryDate);
        frame.add(ProductCost);
        frame.add(Producttype);
        frame.add(ProductQuantText);
        frame.add(ProductEDText);
        frame.add(ProductCostText);
        frame.add(ProductTypeText);
        frame.add(update);
        frame.add(resultText);
        
        frame.setLayout(null);  
        frame.setVisible(true);
        frame.setBounds(10, 10, 700, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);  

        ids.addItemListener(new ItemListener() {
		public void itemStateChanged(ItemEvent ae) {
            
            try     
            {
            	    ResultSet rs;
                    rs = stmt.executeQuery("SELECT * FROM Product where product_id ='"+ids.getSelectedItem()+"'");
                    rs.next();
                    ProductIDText.setText(rs.getString(1));
                    ProductnameText.setText(rs.getString(2));
                    ProductQuantText.setText(rs.getString(4));
                    ProductEDText.setText(rs.getString(3));
                    ProductTypeText.setText(rs.getString(6));
                    ProductCostText.setText(rs.getString(5));
                } 
                catch (SQLException selectException) 
                {
                    displaySQLErrors(selectException);
                }
        }});
        
        update.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            try 
                {   
                    int i = stmt.executeUpdate("UPDATE Product "
                    + "SET product_id='" + ProductIDText.getText() + "', "
                    + "product_name='" + ProductnameText.getText() + "', "
                    + "product_quantity='" + ProductQuantText.getText() + "', "
                    + "product_expirydate='" + ProductEDText.getText() + "', "
                    + "product_cost=" + ProductCostText.getText() + ", "
                    + "product_type='" + ProductTypeText.getText() + "'" + " WHERE product_id = '"
                    + ids.getSelectedItem()+"'");
                    
                    resultText.append("\nUpdated " + i + " rows successfully");
                    ids.removeAll();
                    loadProducts();
                } 
                catch (SQLException insertException) 
                {
                    displaySQLErrors(insertException);
                }
        }});
    }
}
